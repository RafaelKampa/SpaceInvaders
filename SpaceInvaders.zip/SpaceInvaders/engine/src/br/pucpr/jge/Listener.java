package br.pucpr.jge;

public interface Listener {
	public void notify(Object obs);
}
