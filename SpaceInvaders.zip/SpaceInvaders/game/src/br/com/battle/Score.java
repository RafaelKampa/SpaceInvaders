package br.com.battle;

import br.pucpr.jge.GameObject;

public class Score extends GameObject {
    public Score(String spriteName, double x, double y) {
        super(spriteName, x, y);
    }
}